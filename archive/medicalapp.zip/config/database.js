if(process.env.NODE_ENV === 'production'){
  module.exports = {mongoURI: 'mongodb://asmiapp:asmiapp1@ds115472.mlab.com:15472/asmiapp'}
} else {
  module.exports = {mongoURI: 'mongodb://localhost:27017/medicalapp'}
}